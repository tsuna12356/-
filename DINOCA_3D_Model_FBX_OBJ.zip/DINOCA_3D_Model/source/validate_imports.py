"""Round-trip OBJ and FBX using Blender, assert complete usable mesh imports."""
import bpy
import bmesh
import json
import math
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[1]
report={}
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'DINOCA_Studio.blend'))
depsgraph=bpy.context.evaluated_depsgraph_get()
hole_checks=[]
for i in range(6):
    z=(.932+i*.037-.034)*(1.2/1.154)
    origin=Vector((-.001*(1.2/1.154),-.1,z))
    result=bpy.context.scene.ray_cast(depsgraph,origin,Vector((0,1,0)),distance=.2)
    assert not result[0],('Grip cutout is obstructed',i)
    rail=Vector((-.011*(1.2/1.154),-.1,z))
    result=bpy.context.scene.ray_cast(depsgraph,rail,Vector((0,1,0)),distance=.2)
    assert result[0],('Grip rail missing',i)
    hole_checks.append({'index':i+1,'through_cutout_clear':True,'adjacent_frame_present':True})
report['native_grip_cutouts']=hole_checks
for ext in ('obj','fbx'):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    path=ROOT/'exports'/('DINOCA_Green.'+ext)
    if ext=='obj':
        bpy.ops.wm.obj_import(filepath=str(path),forward_axis='NEGATIVE_Z',up_axis='Y')
    else:
        bpy.ops.import_scene.fbx(filepath=str(path),use_custom_normals=True)
    objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
    assert objects,'No meshes imported'
    points=[o.matrix_world@v.co for o in objects for v in o.data.vertices]
    assert all(math.isfinite(c) for v in points for c in v),'Nonfinite coordinates'
    dims=[max(p[i] for p in points)-min(p[i] for p in points) for i in range(3)]
    assert abs(max(dims)-1.2)<.00001,('Incorrect dimensions',dims)
    assert len(objects)>=8,('Lost material assemblies',len(objects))
    materials={m.name for o in objects for m in o.data.materials if m}
    assert len(materials)==10,('Lost materials',materials)
    assert all(len(o.data.uv_layers)>0 for o in objects),'Missing UV coordinates'
    boundary=nonmanifold=degenerate=0
    vertices=triangles=0
    for o in objects:
        bm=bmesh.new()
        bm.from_mesh(o.data)
        boundary+=sum(e.is_boundary for e in bm.edges)
        nonmanifold+=sum(not e.is_manifold for e in bm.edges)
        degenerate+=sum(f.calc_area()<1e-15 for f in bm.faces)
        vertices+=len(bm.verts)
        triangles+=sum(len(f.verts)-2 for f in bm.faces)
        bm.free()
    assert boundary==0,(ext,'Open edges',boundary)
    assert nonmanifold==0,(ext,'Nonmanifold edges',nonmanifold)
    assert degenerate==0,(ext,'Degenerate polygons',degenerate)
    report[ext]={'imported_mesh_objects':len(objects),'materials':len(materials),
                 'vertices':vertices,'triangles':triangles,'dimensions_m':dims,
                 'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,
                 'degenerate_faces':degenerate,'all_meshes_have_uvs':True,'passed':True}
(ROOT/'import_validation.json').write_text(json.dumps(report,indent=2))
print('IMPORT_VALIDATION',json.dumps(report),flush=True)
