"""DINОCA reference-inspired decorative light blade. Run with Blender 4.3+."""
import bpy
import bmesh
import math
import json
from pathlib import Path
from mathutils import Vector, Matrix

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'exports'
PREVIEW = ROOT / 'previews'
OUT.mkdir(exist_ok=True)
PREVIEW.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for d in list(bpy.data.materials):
    bpy.data.materials.remove(d)

scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.length_unit = 'METERS'
scene.unit_settings.scale_length = 1.0
asset = bpy.data.collections.new('DINOCA | detailed decorative light blade')
scene.collection.children.link(asset)

def move_to_asset(o):
    for c in list(o.users_collection):
        c.objects.unlink(o)
    asset.objects.link(o)
    return o

def material(name, color, metallic=0.0, roughness=0.4, emission=None):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*color,1)
    m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metallic
    p.inputs['Roughness'].default_value=roughness
    if emission:
        p.inputs['Emission Color'].default_value=(*color,1)
        p.inputs['Emission Strength'].default_value=emission
    return m

metal=material('01 | Graphite anodized aluminum',(.014,.019,.022),.68,.38)
edge=material('02 | Brushed titanium chamfers',(.055,.069,.078),.82,.3)
rubber=material('03 | Microtextured charcoal polymer',(.018,.024,.028),.14,.54)
black=material('04 | Deep recessed channel',(.004,.007,.009),.45,.34)
silver=material('05 | Stainless fasteners',(.31,.36,.39),.92,.24)
inlay=material('06 | Olive carbon inlay',(.049,.064,.046),.55,.4)
line=material('07 | Muted green enamel markings',(.2,.32,.11),.35,.35)
white=material('08 | White charge indicators',(.76,.95,.86),.1,.25,3.0)
led=material('09 | Neon light guide',(.06,1.0,.002),.12,.22,2.5)
led_core=material('10 | Hot emitter core',(.26,1.0,.02),.05,.2,3.0)
gold=material('11 | USB contacts',(.62,.39,.08),.8,.24)

# Procedural finish is for the native .blend. Exported assets retain base materials.
for m,scale,strength,distance in [(metal,1250,.16,.00008),(rubber,900,.3,.00012),(inlay,1600,.2,.00008)]:
    nt=m.node_tree
    noise=nt.nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value=scale
    noise.inputs['Detail'].default_value=2
    bump=nt.nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value=strength
    bump.inputs['Distance'].default_value=distance
    nt.links.new(noise.outputs['Fac'],bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'],nt.nodes.get('Principled BSDF').inputs['Normal'])

def mesh_obj(name, verts, faces, mat):
    me=bpy.data.meshes.new(name)
    me.from_pydata(verts,[],faces)
    me.update()
    ob=bpy.data.objects.new(name,me)
    asset.objects.link(ob)
    if mat: me.materials.append(mat)
    return ob

def apply_mod(o,mod):
    bpy.context.view_layer.objects.active=o
    bpy.ops.object.modifier_apply(modifier=mod.name)

def bevel(o,width=.0007,segments=3):
    spans=[max(v.co[i] for v in o.data.vertices)-min(v.co[i] for v in o.data.vertices) for i in range(3)]
    width=min(width,min(s for s in spans if s>1e-10)*.35)
    m=o.modifiers.new('Precision radiused edges','BEVEL')
    m.width=width
    m.segments=segments
    apply_mod(o,m)
    return o

def extrude(name,poly,depth,mat,y=0,bev=0):
    # Normalize polygon orientation in XZ before booleans: outward solids are essential.
    area=sum(poly[i][0]*poly[(i+1)%len(poly)][1]-poly[(i+1)%len(poly)][0]*poly[i][1] for i in range(len(poly)))
    if area<0:poly=list(reversed(poly))
    n=len(poly)
    v=[(x,y-depth/2,z) for x,z in poly]+[(x,y+depth/2,z) for x,z in poly]
    f=[tuple(range(n)),tuple(reversed(range(n,n*2)))]
    f += [(i+n,(i+1)%n+n,(i+1)%n,i) for i in range(n)]
    o=mesh_obj(name,v,f,mat)
    if bev: bevel(o,bev)
    return o

def box(name,loc,scale,mat,bev=.0005):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=move_to_asset(bpy.context.object)
    o.name=name
    o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(mat)
    if bev: bevel(o,bev)
    return o

def cylinder(name,loc,r,depth,mat,vertices=32,axis='Y',bev=.0002):
    rot=(math.pi/2,0,0) if axis=='Y' else (0,0,0)
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=loc,rotation=rot)
    o=move_to_asset(bpy.context.object)
    o.name=name
    o.data.materials.append(mat)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if bev: bevel(o,bev,2)
    return o

def capsule(cx,cz,w,h,n=12):
    r=w/2
    dy=h/2-r
    pts=[]
    for i in range(n+1):
        a=math.pi*i/n
        pts.append((cx+r*math.cos(a),cz+dy+r*math.sin(a)))
    for i in range(n+1):
        a=math.pi+math.pi*i/n
        pts.append((cx+r*math.cos(a),cz-dy+r*math.sin(a)))
    return pts

def subtract(o,cutter):
    mod=o.modifiers.new('Real through cutout','BOOLEAN')
    mod.operation='DIFFERENCE'
    mod.solver='EXACT'
    mod.object=cutter
    apply_mod(o,mod)
    bpy.data.objects.remove(cutter,do_unlink=True)

def ribbon(name,points,width,depth,mat):
    # Closed swept mesh with a beveled rectangular cross section.
    profile=[(-.5,-.25),(-.35,-.5),(.35,-.5),(.5,-.25),(.5,.25),(.35,.5),(-.35,.5),(-.5,.25)]
    v=[]
    for i,p in enumerate(points):
        a=Vector(points[max(0,i-1)])
        b=Vector(points[min(len(points)-1,i+1)])
        dx,dz=b.x-a.x,b.z-a.z
        mag=max(1e-9,math.sqrt(dx*dx+dz*dz))
        nx,nz=dz/mag,-dx/mag
        for s,d in profile:
            v.append((p[0]+nx*s*width,p[1]+d*depth,p[2]+nz*s*width))
    f=[]
    for i in range(len(points)-1):
        for j in range(8):
            f.append((i*8+j,i*8+(j+1)%8,(i+1)*8+(j+1)%8,(i+1)*8+j))
    f.extend([tuple(reversed(range(8))),tuple((len(points)-1)*8+j for j in range(8))])
    return mesh_obj(name,v,f,mat)

def screw(x,z,side,r=.0017,name='Torx fastener'):
    y=side*.0085
    cylinder(name+' recessed seat',(x,y,z),r*1.34,.00065,black)
    cylinder(name+' metal head',(x,y+side*.0005,z),r,.00065,silver)
    # Six-lobed dark socket modeled as a small inset prism.
    poly=[]
    for j in range(24):
        a=j*math.tau/24
        rr=r*(.46 if j%4 in (0,3) else .32)
        poly.append((x+rr*math.cos(a),z+rr*math.sin(a)))
    extrude(name+' six lobe socket',poly,.00015,black,y+side*.00087)

# Blade: an intentionally broad, blunt light-prop housing, with a swept tip.
def blade(t):
    x=.006*t+.045*t**8
    z=.839-.805*t
    w=.044*(1-.12*t*t)*math.sqrt(max(.00004,1-t**14))
    return x,z,w

N=128
profile=[(-.5,0),(-.41,-.42),(-.28,-.5),(.32,-.5),(.5,-.10),(.5,.10),(.32,.5),(-.28,.5),(-.41,.42)]
v=[]
for i in range(N+1):
    t=i/N
    x,z,w=blade(t)
    thick=.010*(1-.65*t**12)
    for px,py in profile:
        v.append((x+px*w,py*thick,z))
f=[]
for i in range(N):
    for j in range(9):
        f.append((i*9+j,i*9+(j+1)%9,(i+1)*9+(j+1)%9,(i+1)*9+j))
f.extend([tuple(reversed(range(9))),tuple(N*9+j for j in range(9))])
body=mesh_obj('BLADE | swept chamfered graphite housing',v,f,metal)
body.data.materials.append(edge)
for p in body.data.polygons:
    if p.index<N*9 and p.index%9 in (0,1,3,5,7,8): p.material_index=1

for side in (-1,1):
    # Neon strip nested inside a black channel, duplicated on both faces.
    path=[]
    spine=[]
    for i in range(119):
        t=.042+.945*i/118
        x,z,w=blade(t)
        path.append((x+w*.19,side*.00505,z))
        spine.append((x-w*.35,side*.0046,z))
    ribbon('BLADE | recessed LED channel '+str(side),path,.008,.0012,black)
    ribbon('BLADE | continuous light diffuser '+str(side),[(x,y+side*.0004,z) for x,y,z in path],.00325,.0007,led)
    ribbon('BLADE | high intensity luminous core '+str(side),[(x+.00055,y+side*.00081,z) for x,y,z in path],.00064,.00022,led_core)
    ribbon('BLADE | outer spine seam '+str(side),spine,.00075,.00028,black)
    # A short parallel tracer at the shoulder; small machined bridges downstream.
    tracer=[]
    for i in range(25):
        t=.06+.24*i/24
        x,z,w=blade(t)
        tracer.append((x-w*.22,side*.00512,z))
    ribbon('BLADE | secondary shoulder light '+str(side),tracer,.0008,.0004,led)
    for k in range(12):
        t=.10+k*.068
        x,z,w=blade(t)
        xx=x+w*.18
        ribbon('BLADE | emitter station %02d %s'%(k,side),[(xx,side*.0062,z),(xx-.0031,side*.0062,z-.002)],.0008,.00045,led)
        ribbon('BLADE | slotted seam %02d %s'%(k,side),[(x-w*.33,side*.00515,z+.002),(x-w*.19,side*.00515,z-.002)],.00065,.0002,black)
    # Three precision rivets in the spine, in low profile rather than oversized bolts.
    for t in (.13,.46,.75):
        x,z,w=blade(t)
        cylinder('BLADE | flush micro rivet',(x-w*.30,side*.00535,z),.00085,.0003,silver,24,bev=.00008)

# Shoulder and asymmetrical angular guard.
shoulder=[(-.023,.814),(.019,.814),(.023,.866),(.013,.899),(-.017,.899),(-.028,.861)]
extrude('HILT | graphite power collar',shoulder,.015,metal,bev=.001)
guard=[(-.025,.856),(-.045,.884),(-.042,.895),(-.025,.888),(-.013,.902),(.014,.897),(.028,.88),(.022,.867),(.009,.878),(-.010,.875)]
extrude('HILT | asymmetric swept guard',guard,.019,metal,bev=.00085)
for side in (-1,1):
    side_y=side*.00805
    panel=[(-.018,.819),(.010,.819),(.014,.851),(.007,.871),(-.010,.875),(-.021,.851)]
    extrude('HILT | inset electronics face '+str(side),panel,.001,black,side_y,bev=.0004)
    # Three white battery lamps on each side.
    for i in range(3):
        cylinder('HILT | battery indicator bezel',(-.004,side*.0091,.848-i*.009),.0024,.0008,edge,32)
        cylinder('HILT | white battery indicator',(-.004,side*.0097,.848-i*.009),.0014,.0005,white,32)
    for i in range(4):
        x=-.031+i*.004
        z=.887-i*.0026
        ribbon('HILT | guard machining groove',[(x,side*.0097,z),(x+.008,side*.0097,z-.010)],.0011,.00024,black)
    screw(.008,.862,side,.00135,'Collar Torx')
    screw(-.017,.884,side,.0014,'Guard Torx')

# Long vented handle: genuine rounded cutouts through the full depth.
grip_poly=[(-.015,.89),(.014,.89),(.011,1.177),(.007,1.188),(-.008,1.188),(-.015,1.177)]
grip=extrude('GRIP | skeletonized frame with six through vents',grip_poly,.013,metal)
holes=[]
for i in range(6):
    z=.932+i*.037
    w=.0122-i*.00025
    h=.0275 if i<5 else .023
    hole=extrude('temporary grip vent',capsule(-.001,z,w,h,16),.050,None)
    subtract(grip,hole)
    holes.append((-.001,z,w,h))
bevel(grip,.00072,3)

# Thin raised rings follow each real vent, on each visible face.
for side in (-1,1):
    for k,(x,z,w,h) in enumerate(holes):
        pp=capsule(x,z,w+.0014,h+.0014,16)
        pts=[(px,side*.00664,pz) for px,pz in pp+[pp[0]]]
        ribbon('GRIP | vent chamfer rim %02d %s'%(k,side),pts,.00055,.00045,edge)
    # Grip knurl teeth on two outer rails.
    for j in range(50):
        z=.914+j*.00505
        for rail in (-1,1):
            x=(-.0121 if rail<0 else .0093)-(.0005*(z-.914)/.25)
            ribbon('GRIP | diagonal rail knurl',[(x-.0014,side*.0067,z+.0013),(x+.0014,side*.0067,z-.0013)],.00062,.0004,inlay)
    # Four diagonal webs close to the handle root.
    for j in range(4):
        z=.899+j*.004
        ribbon('GRIP | root diagonal tread', [(-.011,side*.0068,z+.005),(.007,side*.0068,z-.004)],.0013,.0008,rubber)
    for z in (.902,1.179):
        screw(-.001,z,side,.00155,'Grip retaining Torx')

# Narrow transverse bands with finely stepped edges.
for z in (.895,1.182):
    box('GRIP | end collar',(-.001,0,z),(.027,.015,.0055),rubber,.00065)
    for dz in (-.0031,.0031):
        box('GRIP | collar metal seam',(-.001,0,z+dz),(.0275,.0153,.0007),edge,.0002)

# A recessed USB-C socket is interpreted from the reference's USB charging badge.
# It is decorative, on the side of the electronics collar.
box('POWER | port seat',(.021,0,.858),(.0016,.010,.016),black,.0008)
box('POWER | USB C outer shell',(.022,0,.858),(.001,.0078,.0105),edge,.0007)
box('POWER | USB C dark mouth',(.0226,0,.858),(.0003,.0056,.0083),black,.0008)
box('POWER | USB C central tongue',(.0229,0,.858),(.00035,.0013,.006),rubber,.0003)
for i in range(6):
    box('POWER | individual connector contact',(.0231,-.0016+i*.00064,.858),(.0002,.00025,.0038),gold,.00004)

# Additional details on the back of the power collar, kept low profile.
for side in (-1,1):
    box('HILT | access panel seam',(-.019,side*.0084,.834),(.003,.0007,.020),rubber,.0004)
    for dz in (-.007,.007):
        cylinder('HILT | panel captive screw',(-.019,side*.009,.834+dz),.00075,.0004,silver,24,bev=.0001)

# Put the origin at the tip, and choose an explicit estimated overall height of 1.20 m.
world_points=[o.matrix_world@v.co for o in asset.objects for v in o.data.vertices]
min_z=min(v.z for v in world_points)
max_z=max(v.z for v in world_points)
scale=1.2/(max_z-min_z)
offset=Vector((0,0,min_z))
for o in asset.objects:
    world=o.matrix_world.copy()
    for v in o.data.vertices:v.co=(world@v.co-offset)*scale
    o.matrix_world=Matrix.Identity(4)
    o.data.update()

# Normalize winding and build real UVs before any export.
for o in list(asset.objects):
    if o.type!='MESH': continue
    bm=bmesh.new()
    bm.from_mesh(o.data)
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=1e-9)
    bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=1e-9)
    bm.to_mesh(o.data)
    bm.free()
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True)
    bpy.context.view_layer.objects.active=o
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')
    for p in o.data.polygons: p.use_smooth=False
    if not o.data.uv_layers:
        uv=o.data.uv_layers.new(name='UVMap')
        for face in o.data.polygons:
            normal=face.normal
            axis=max(range(3),key=lambda a:abs(normal[a]))
            for li in face.loop_indices:
                co=o.data.vertices[o.data.loops[li].vertex_index].co
                # Dominant-axis projection: 1 unit in UV = 1 meter in the model.
                uv.data[li].uv=((co.x+.1,co.z) if axis==1 else ((co.y+.1,co.z) if axis==0 else (co.x+.1,co.y+.1)))

# Join by material to reduce draw calls while preserving logical named mesh parts.
for mat in list(bpy.data.materials):
    group=[o for o in list(asset.objects) if len(o.data.materials)==1 and o.data.materials[0]==mat]
    if len(group)<2: continue
    bpy.ops.object.select_all(action='DESELECT')
    for o in group:o.select_set(True)
    bpy.context.view_layer.objects.active=group[0]
    bpy.ops.object.join()
    group[0].name='ASSEMBLY | '+mat.name

for o in asset.objects:
    o['asset_type']='Decorative illuminated sci-fi blade; nonfunctional visual asset'
    o['units']='meters'
    o['reference']='User-provided single-view DINOCA product reference'

# Export exactly the asset meshes, with transforms and material names intact.
def select_asset():
    bpy.ops.object.select_all(action='DESELECT')
    for o in asset.objects:o.select_set(True)
    bpy.context.view_layer.objects.active=next(iter(asset.objects))

COLORS={
    'Green':((.06,1.0,.002),(.26,1.0,.02)),
    'Blue':((.008,.12,1.0),(.06,.42,1.0)),
    'Red':((1.0,.008,.045),(1.0,.05,.12)),
    'Yellow':((1.0,.64,.008),(1.0,.88,.09))}

def color_material(m,col):
    m.diffuse_color=(*col,1)
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*col,1)
    p.inputs['Emission Color'].default_value=(*col,1)

for label,(col,core) in COLORS.items():
    color_material(led,col)
    color_material(led_core,core)
    select_asset()
    bpy.ops.wm.obj_export(filepath=str(OUT/('DINOCA_'+label+'.obj')),export_selected_objects=True,
        forward_axis='NEGATIVE_Z',up_axis='Y',export_uv=True,export_normals=True,
        export_materials=True,export_triangulated_mesh=True,apply_modifiers=True)
    bpy.ops.export_scene.fbx(filepath=str(OUT/('DINOCA_'+label+'.fbx')),use_selection=True,
        object_types={'MESH'},global_scale=1.0,apply_unit_scale=True,
        axis_forward='-Z',axis_up='Y',bake_anim=False,use_mesh_modifiers=True,
        mesh_smooth_type='FACE',path_mode='AUTO',add_leaf_bones=False)
color_material(led,COLORS['Green'][0])
color_material(led_core,COLORS['Green'][1])

# Studio environment; no part of it is included in the exported mesh assets.
studio=bpy.data.collections.new('STUDIO | cameras and lighting, excluded from mesh exports')
scene.collection.children.link(studio)
def studio_move(o):
    for c in list(o.users_collection):c.objects.unlink(o)
    studio.objects.link(o)
    return o

def area(name,loc,power,color,size,target):
    bpy.ops.object.light_add(type='AREA',location=loc)
    o=studio_move(bpy.context.object)
    o.name=name
    o.data.energy=power
    o.data.color=color
    o.data.shape='DISK'
    o.data.size=size
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    return o

area('Key | broad cool softbox',(-.55,-.8,1.1),32,(.76,.86,1),.7,(0,0,.62))
area('Rim | warm strip',(.4,.15,.75),45,(1,.64,.34),.55,(0,0,.62))
area('Fill | graphite structure',(.35,-.6,.42),12,(.72,1,.88),.45,(0,0,.65))
area('Grip | overhead',(-.1,.1,1.6),24,(.8,.86,1),.5,(0,0,1))

world=bpy.data.worlds.new('Dark navy studio')
world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.017,.025,.038,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.42
scene.world=world

def camera(name,loc,target,scale):
    bpy.ops.object.camera_add(location=loc)
    o=studio_move(bpy.context.object)
    o.name=name
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    o.data.type='ORTHO'
    o.data.ortho_scale=scale
    o.data.lens=70
    return o

hero=camera('CAMERA | three-quarter product view',(.8,-3.7,1.12),(0,0,.609),1.31)
front=camera('CAMERA | reference silhouette',(0,-4,.612),(0,0,.612),1.29)
detail=camera('CAMERA | grip engineering detail',(.32,-1.8,1.17),(-.008,0,1.006),.44)
tipcam=camera('CAMERA | illuminated swept tip',(.18,-1.5,.35),(.006,0,.15),.29)

scene.render.engine='CYCLES'
scene.cycles.samples=64
# This cloud Blender build has no OpenImageDenoise support.
scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED'
scene.render.threads=5
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
scene.render.image_settings.file_format='PNG'
scene.render.film_transparent=False
scene.use_nodes=True
nt=scene.node_tree
nt.nodes.clear()
layers=nt.nodes.new('CompositorNodeRLayers')
glare=nt.nodes.new('CompositorNodeGlare')
glare.glare_type='FOG_GLOW'
glare.quality='HIGH'
glare.threshold=1.3
glare.size=7
composite=nt.nodes.new('CompositorNodeComposite')
nt.links.new(layers.outputs['Image'],glare.inputs['Image'])
nt.links.new(glare.outputs['Image'],composite.inputs['Image'])

def render(cam,name,w,h):
    scene.camera=cam
    scene.render.resolution_x=w
    scene.render.resolution_y=h
    scene.render.resolution_percentage=100
    scene.render.filepath=str(PREVIEW/name)
    bpy.ops.render.render(write_still=True)

stats={'objects':len(asset.objects),'vertices':sum(len(o.data.vertices) for o in asset.objects),
       'polygons':sum(len(o.data.polygons) for o in asset.objects),
       'triangles':sum(len(p.vertices)-2 for o in asset.objects for p in o.data.polygons),
       'materials':len({m.name for o in asset.objects for m in o.data.materials}),
       'units':'meters','height_m':1.2,'up_axis_blend':'Z','up_axis_exports':'Y',
       'origin':'blade tip at Z=0 in the native Blender scene',
       'real_grip_through_holes':6,'double_sided_light_guides':True}
(ROOT/'asset_stats.json').write_text(json.dumps(stats,indent=2))
print('ASSET_STATS',json.dumps(stats),flush=True)

scene.camera=hero
scene.render.resolution_x=1000
scene.render.resolution_y=1600
select_asset()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'DINOCA_Studio.blend'))
render(hero,'hero_green.png',1000,1600)
render(detail,'detail_grip.png',1100,1000)
render(tipcam,'detail_tip.png',1000,1000)
render(front,'front_green.png',700,1600)

# Separate product lineup for comparing the four exported colorways.
variants=bpy.data.collections.new('PREVIEW | four color variants')
scene.collection.children.link(variants)
for j,(label,(col,core)) in enumerate(COLORS.items()):
    variant_led=led.copy()
    variant_core=led_core.copy()
    color_material(variant_led,col)
    color_material(variant_core,core)
    for original in list(asset.objects):
        o=original.copy()
        o.data=original.data.copy()
        o.name=label+' | '+original.name
        variants.objects.link(o)
        o.location.x+=(-.24+j*.16)
        for slot in o.material_slots:
            if slot.material==led:slot.material=variant_led
            elif slot.material==led_core:slot.material=variant_core
asset.hide_render=True
lineup=camera('CAMERA | four colors',(.16,-4,1.05),(0,0,.611),1.35)
render(lineup,'four_colors.png',1200,1600)
asset.hide_render=False
print('BUILD_COMPLETE',flush=True)
